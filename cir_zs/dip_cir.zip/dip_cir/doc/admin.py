from django.contrib import admin
from .models import Doc

# Register your models here.
admin.site.register(Doc)


#
# class DocsFilesIn(admin.TabularInline):
#     model = Doc

