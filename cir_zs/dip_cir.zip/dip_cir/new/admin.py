from django.contrib import admin
from .models import New

admin.site.register(New)